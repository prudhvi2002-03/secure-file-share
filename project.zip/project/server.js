require('dotenv').config();
const express = require('express');
const nodemailer = require('nodemailer');
const multer = require('multer');
const crypto = require('crypto');
const fs = require('fs').promises;
const path = require('path');
const cors = require('cors');

const app = express();
const port = 3001;

// Middleware
app.use(cors());
app.use(express.json());

// Serve index.html at root
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Configure Multer for file storage
const storage = multer.diskStorage({
  destination: './uploads',
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  },
});
const upload = multer({ storage });

// Ensure uploads directory exists
fs.mkdir('./uploads', { recursive: true }).catch(console.error);

// In-memory store for secure links (use a database in production)
const secureLinks = new Map();

// Nodemailer transporter setup
const transporter = nodemailer.createTransport({
  service: 'gmail', // Replace with your email service
  auth: {
    user: process.env.EMAIL_USER, // Set in .env
    pass: process.env.EMAIL_PASS, // Set in .env
  },
});

// Send email with attachments
app.post('/send-email', upload.array('files'), async (req, res) => {
  try {
    const { to, message } = req.body;
    const files = req.files;

    if (!to || !files || files.length === 0) {
      return res.status(400).json({ success: false, error: 'Recipient email and files are required' });
    }

    // Prepare email
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to,
      subject: 'Secure File Share from Cloud Fuze',
      text: message || 'You have received secure files from Cloud Fuze.',
      attachments: files.map(file => ({
        filename: file.originalname,
        path: file.path,
      })),
    };

    // Send email
    await transporter.sendMail(mailOptions);

    // Cleanup files after sending
    for (const file of files) {
      await fs.unlink(file.path).catch(console.error);
    }

    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Generate secure link
app.post('/generate-secure-link', upload.array('files'), async (req, res) => {
  try {
    const { password, expiry } = req.body;
    const files = req.files;

    if (!password || !files || files.length === 0) {
      return res.status(400).json({ success: false, error: 'Password and files are required' });
    }

    // Generate unique link ID
    const linkId = crypto.randomBytes(12).toString('hex');
    const secureLink = `http://localhost:${port}/download/${linkId}`;

    // Encrypt file paths (simple example, use stronger encryption in production)
    const encryptedFiles = files.map(file => ({
      originalname: file.originalname,
      path: file.path,
      encryptedPath: crypto.createHash('sha256').update(file.path + password).digest('hex'),
    }));

    // Store link data
    secureLinks.set(linkId, {
      files: encryptedFiles,
      password: crypto.createHash('sha256').update(password).digest('hex'),
      expiry: expiry ? new Date(expiry).getTime() : null,
    });

    // Schedule cleanup if expiry is set
    if (expiry) {
      const timeToExpiry = new Date(expiry).getTime() - Date.now();
      setTimeout(() => cleanupLink(linkId), timeToExpiry);
    }

    res.json({ success: true, link: secureLink, expires: expiry || 'No expiration' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Download files with password
app.get('/download/:linkId', async (req, res) => {
  const { linkId } = req.params;
  const { password } = req.query;

  const linkData = secureLinks.get(linkId);
  if (!linkData) {
    return res.status(404).send('Link not found or expired');
  }

  // Verify password
  const hashedPassword = crypto.createHash('sha256').update(password).digest('hex');
  if (hashedPassword !== linkData.password) {
    return res.status(401).send('Invalid password');
  }

  // Check expiry
  if (linkData.expiry && Date.now() > linkData.expiry) {
    await cleanupLink(linkId);
    return res.status(410).send('Link has expired');
  }

  // Serve files
  res.set('Content-Type', 'application/octet-stream');
  for (const file of linkData.files) {
    try {
      await fs.access(file.path);
      res.download(file.path, file.originalname);
    } catch (err) {
      console.error(err);
    }
  }
});

// Cleanup expired link and files
async function cleanupLink(linkId) {
  const linkData = secureLinks.get(linkId);
  if (linkData) {
    for (const file of linkData.files) {
      await fs.unlink(file.path).catch(console.error);
    }
    secureLinks.delete(linkId);
  }
}

// Start server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});